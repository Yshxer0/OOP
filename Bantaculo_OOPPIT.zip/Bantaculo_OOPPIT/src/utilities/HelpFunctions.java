package utilities;
public interface HelpFunctions {

public double computeChange(double cash, double amount_due);



public void generateReceipt(String no, String uName, String email, String id, String name, int quantity, double price,
		double total, double cash, double change);



}
