package ProductDB;

public abstract class Product {
	public String id;
	public String name;
	public String description;
	public int quantity_stock;
	public double price;
	public double total;
	public double sales;

	public abstract void purchase(int num_pcs);






}
