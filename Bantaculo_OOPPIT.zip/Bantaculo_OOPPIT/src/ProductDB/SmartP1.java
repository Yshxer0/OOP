package ProductDB;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JOptionPane;

import utilities.HelpFunctions;

public class SmartP1 extends Product implements HelpFunctions{

	Connection conn = null;
	Statement stmt;
	PreparedStatement pst;
	ResultSet res;

	public void main() {
		conn =  dbconnect();
		data();
	}

	private Connection dbconnect() {
	    try {
	        Class.forName("org.sqlite.JDBC");
	        conn = DriverManager.getConnection("JDBC:sqlite:C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Stock.sqlite");
	        return conn;
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(null, "Connection Error: " + e);
	        return null;
	    }
	}

	public void data() {
	    String query = "select * from Stocks where ID = '6243098517'";
	    try {
	        pst = conn.prepareStatement(query);
	        res = pst.executeQuery();
	        while (res.next()) {
	            name = res.getString("Name");
	            id = res.getString("ID");
	            description = res.getString("Description");
	            price = Double.parseDouble(res.getString("Price"));
	            quantity_stock = Integer.parseInt(res.getString("Stock"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public double computeChange(double cash, double amount_due) {
		sales = cash-amount_due;
		return sales;
	}

	@Override
	public void purchase(int num_pcs) {
		quantity_stock-=num_pcs;
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate("update Stocks set Stock = "+quantity_stock+" where ID = '6243098517'");
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}

	@Override
	public void generateReceipt(String no, String uName, String email, String id, String name, int quantity, double price, double total,
            double cash, double change) {

			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String formattedDateTime = now.format(formatter);
			
			String filePath = "C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\receipt.txt";
			File existingFile = new File(filePath);
			
			if (existingFile.exists()) {
			String fileNameWithoutExtension = existingFile.getName().replaceFirst("[.][^.]+$", "");
			String fileExtension = filePath.substring(filePath.lastIndexOf("."));
			String newFileName = fileNameWithoutExtension + "_" + formattedDateTime.replaceAll("[:]", "_") + fileExtension;
			String newFilePath = existingFile.getParent() + File.separator + newFileName;
			filePath = newFilePath;
			}
			
			try {
			FileWriter fileWriter = new FileWriter(filePath);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			
			bufferedWriter.write("_____________________________________________________________________________\n");
			bufferedWriter.write("                              SAMSUNG STORE INC\n");
			bufferedWriter.write("                        XX XXXX AVENUE XXXX XX CITY\n");
			bufferedWriter.write("                                  Receipt\n");
			bufferedWriter.write("\n");
			bufferedWriter.write(" Transaction Date: " + formattedDateTime + "\n");
			bufferedWriter.write(" Transaction ID: " + no + "\n");
			bufferedWriter.write("\n");
			bufferedWriter.write("-----------------------------------------------------------------------------\n");
			bufferedWriter.write("\n");
			bufferedWriter.write(" ID:                                 |           " + id + "\n");
			bufferedWriter.write(" Item Name:                          |           " + name + "\n");
			bufferedWriter.write(" Quantity:                           |           "+ quantity + "\n");
			bufferedWriter.write(" Price:                              |           Php " + price + "\n");
			bufferedWriter.write("\n");
			bufferedWriter.write("-----------------------------------------------------------------------------\n");
			bufferedWriter.write("\n");
			bufferedWriter.write(" Total Amount:                                              Php " + total + "\n");
			bufferedWriter.write(" Cash:                                                      Php " + cash + "\n");
			bufferedWriter.write("                                                       ----------------------\n");
			bufferedWriter.write(" Change:                                                    Php " + change + "\n");
			bufferedWriter.write(" Items Purchased: " + quantity + "\n");
			bufferedWriter.write("\n");
			bufferedWriter.write("-----------------------------------------------------------------------------\n");
			bufferedWriter.write("\n");
			bufferedWriter.write(" Dealer: SAMSUNG\n");
			bufferedWriter.write(" Name: " + uName + "\n");
			bufferedWriter.write(" Email: " + email + "\n");
			bufferedWriter.write("\n");
			bufferedWriter.write("_____________________________________________________________________________\n");
			
			bufferedWriter.close();
			
			JOptionPane.showMessageDialog(null, "Receipt Printed Successfully");
			File fileToOpen = new File(filePath);
			Desktop.getDesktop().open(fileToOpen);
			} catch (IOException e) {
			e.printStackTrace();
			}
		}
}
