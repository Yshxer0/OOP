package sales;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import ProductDB.*;

public class Cart extends JFrame {

	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtName;
	private JLabel lblPrice;
	private JTextField txtPrice;
	private JLabel lblQuantity;
	private JTextField txtQuantity;
	private JTextField txtTotal;
	private JTextField txtCash;
	private JTextField txtChange;
	private JButton btnSUB;
	private JButton btnADD;
	private JButton btnNewButton;
	private int number;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Cart frame = new Cart();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Laptop1 l1 = new Laptop1();
	Laptop2 l2 = new Laptop2();
	SmartP1 sp1 = new SmartP1();
	SmartP2 sp2 = new SmartP2();
	SmartW1 sw1 = new SmartW1();
	SmartW2 sw2 = new SmartW2();
	Tablet1 t1 = new Tablet1();
	Tablet2 t2 = new Tablet2();
	Connection conn = null;
	Statement stmt;
	PreparedStatement pst;
	ResultSet res;
	Connection conn1 = null;
	Statement stmt1;
	PreparedStatement pst1;
	ResultSet res1;
	private JTextField txtOrder;

	public void initial() {
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setBounds(100, 100, 466, 541);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Product ID");
		lblNewLabel.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblNewLabel.setBounds(34, 116, 158, 26);
		contentPane.add(lblNewLabel);

		txtID = new JTextField();
		txtID.setFont(new Font("Dialog", Font.BOLD, 15));
		txtID.setHorizontalAlignment(SwingConstants.CENTER);
		txtID.setBackground(new Color(255, 255, 255));
		txtID.setEditable(false);
		txtID.setBounds(143, 114, 266, 26);
		contentPane.add(txtID);
		txtID.setColumns(10);

		JLabel lblItemName = new JLabel("Item Name");
		lblItemName.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblItemName.setBounds(34, 154, 158, 26);
		contentPane.add(lblItemName);

		txtName = new JTextField();
		txtName.setHorizontalAlignment(SwingConstants.CENTER);
		txtName.setFont(new Font("Dialog", Font.BOLD, 15));
		txtName.setBackground(new Color(255, 255, 255));
		txtName.setEditable(false);
		txtName.setColumns(10);
		txtName.setBounds(143, 152, 266, 26);
		contentPane.add(txtName);

		JPanel panel_4_3 = new JPanel();
		panel_4_3.setBackground(Color.LIGHT_GRAY);
		panel_4_3.setBounds(12, 60, 425, 4);
		contentPane.add(panel_4_3);

		lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblPrice.setBounds(34, 192, 158, 26);
		contentPane.add(lblPrice);

		txtPrice = new JTextField();
		txtPrice.setFont(new Font("Dialog", Font.BOLD, 15));
		txtPrice.setHorizontalAlignment(SwingConstants.CENTER);
		txtPrice.setBackground(new Color(255, 255, 255));
		txtPrice.setEditable(false);
		txtPrice.setColumns(10);
		txtPrice.setBounds(143, 190, 266, 26);
		contentPane.add(txtPrice);

		lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblQuantity.setBounds(34, 228, 111, 26);
		contentPane.add(lblQuantity);

		btnSUB = new JButton("<");
		btnSUB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DecimalFormat d = new DecimalFormat("0.00");
				 btn();
				  int i = Integer.parseInt(txtQuantity.getText());
				  int j = i - 1;
				  txtQuantity.setText(Integer.toString(j));
				  double k = Double.parseDouble(txtPrice.getText());
				  double l = Double.parseDouble(txtQuantity.getText());
				  double m = k*l;
				  txtTotal.setText(d.format(m));
			}
		});
		btnSUB.setBackground(new Color(255, 255, 255));
		btnSUB.setFont(new Font("Dialog", Font.BOLD, 20));
		btnSUB.setBounds(143, 228, 51, 26);
		contentPane.add(btnSUB);

		txtQuantity = new JTextField();
		txtQuantity.setFont(new Font("Dialog", Font.BOLD, 15));
		txtQuantity.setHorizontalAlignment(SwingConstants.CENTER);
		txtQuantity.setEditable(false);
		txtQuantity.setColumns(10);
		txtQuantity.setBackground(Color.WHITE);
		txtQuantity.setBounds(206, 228, 140, 30);
		contentPane.add(txtQuantity);

		btnADD = new JButton(">");
		btnADD.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DecimalFormat d = new DecimalFormat("0.00");
				 btn();
				  int i = Integer.parseInt(txtQuantity.getText());
				  int j = i + 1;
				  txtQuantity.setText(Integer.toString(j));
				  double k = Double.parseDouble(txtPrice.getText());
				  double l = Double.parseDouble(txtQuantity.getText());
				  double m = k*l;
				  txtTotal.setText(d.format(m));
			}
		});
		btnADD.setBackground(new Color(255, 255, 255));
		btnADD.setFont(new Font("Dialog", Font.BOLD, 20));
		btnADD.setBounds(358, 228, 51, 26);
		contentPane.add(btnADD);

		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblTotal.setBounds(34, 268, 158, 26);
		contentPane.add(lblTotal);

		txtTotal = new JTextField();
		txtTotal.setFont(new Font("Dialog", Font.BOLD, 15));
		txtTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotal.setEditable(false);
		txtTotal.setColumns(10);
		txtTotal.setBackground(Color.WHITE);
		txtTotal.setBounds(143, 266, 266, 26);
		contentPane.add(txtTotal);

		JPanel panel_4_3_1 = new JPanel();
		panel_4_3_1.setBackground(Color.LIGHT_GRAY);
		panel_4_3_1.setBounds(12, 304, 425, 4);
		contentPane.add(panel_4_3_1);

		JLabel lblCash = new JLabel("Cash");
		lblCash.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblCash.setBounds(34, 322, 158, 26);
		contentPane.add(lblCash);

		txtCash = new JTextField();
		txtCash.setFont(new Font("Dialog", Font.BOLD, 15));
		txtCash.setHorizontalAlignment(SwingConstants.CENTER);
		txtCash.setColumns(10);
		txtCash.setBackground(Color.WHITE);
		txtCash.setBounds(143, 320, 266, 26);
		contentPane.add(txtCash);

		JLabel lblChange = new JLabel("Change");
		lblChange.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblChange.setBounds(34, 398, 158, 26);
		contentPane.add(lblChange);

		txtChange = new JTextField();
		txtChange.setFont(new Font("Dialog", Font.BOLD, 15));
		txtChange.setHorizontalAlignment(SwingConstants.CENTER);
		txtChange.setEditable(false);
		txtChange.setColumns(10);
		txtChange.setBackground(Color.WHITE);
		txtChange.setBounds(143, 396, 266, 26);
		contentPane.add(txtChange);

		JButton btnNewButton_1_1 = new JButton("Buy");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DecimalFormat d = new DecimalFormat("0.00");
				int i = Integer.parseInt(txtQuantity.getText());
				String y = txtID.getText();
				double c = Double.parseDouble(txtCash.getText());
				double t = Double.parseDouble(txtTotal.getText());
				
				if(y.equals("8914562037")) {
					if(c>=t) {
						l1.main();
					l1.purchase(i);
					l1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(l1.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("7350189642")) {
					if(c>=t) {
						l2.main();
					l2.purchase(i);
					l2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(l2.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("6243098517")) {
					if(c>=t) {
						sp1.main();
					sp1.purchase(i);
					sp1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sp1.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("5094286173")) {
					if(c>=t) {
						sp2.main();
					sp2.purchase(i);
					sp2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sp2.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("1465827390")) {
					if(c>=t) {
						sw1.main();
					sw1.purchase(i);
					sw1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sw1.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("3078965412")) {
					if(c>=t) {
						sw2.main();
					sw2.purchase(i);
					sw2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sw2.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("4023987165")) {
					if(c>=t) {
						t1.main();
					t1.purchase(i);
					t1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(t1.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y.equals("9157832046")) {
					if(c>=t) {
						t2.main();
					t2.purchase(i);
					t2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(t2.sales));
					call();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				main();
			}
		});
		btnNewButton_1_1.setBounds(340, 358, 70, 26);
		contentPane.add(btnNewButton_1_1);

		JButton btnNewButton_1_1_1 = new JButton("Print Receipt");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String uname = "XXXXXXXXXX";
				String email = "XXXXXXXXXX@gmail.com";
				String id = txtID.getText();
				String name = txtName.getText();
				String order = txtOrder.getText();	
				int quantity = Integer.parseInt(txtQuantity.getText());
				double price = Double.parseDouble(txtPrice.getText());
				double total = Double.parseDouble(txtTotal.getText());
				double cash = Double.parseDouble(txtCash.getText());
				double change = Double.parseDouble(txtChange.getText());
						
				if(id.equals("8914562037")) {
					l1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("7350189642")) {
					l2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("6243098517")) {
					sp1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("5094286173")) {
					sp2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("1465827390")) {
					sw1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("3078965412")) {
					sw2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("4023987165")) {
					t1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(id.equals("9157832046")) {
					t2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
			}
		});
		btnNewButton_1_1_1.setBounds(279, 434, 130, 26);
		contentPane.add(btnNewButton_1_1_1);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\samsung.png"));
		lblNewLabel_1.setBounds(12, 23, 120, 25);
		contentPane.add(lblNewLabel_1);

		btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setBounds(374, 12, 63, 40);
		contentPane.add(btnNewButton);
		
		txtOrder = new JTextField();
		txtOrder.setHorizontalAlignment(SwingConstants.CENTER);
		txtOrder.setFont(new Font("Dialog", Font.BOLD, 15));
		txtOrder.setEditable(false);
		txtOrder.setColumns(10);
		txtOrder.setBackground(Color.WHITE);
		txtOrder.setBounds(143, 78, 266, 26);
		contentPane.add(txtOrder);
		
		JLabel lblOrderNo = new JLabel("Order No.");
		lblOrderNo.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblOrderNo.setBounds(34, 78, 158, 26);
		contentPane.add(lblOrderNo);
	}
	public Cart() {
		setResizable(false);
		initial();
	}
	public Cart(String no, String id, String name, double price, int quantity, double total) {
		setResizable(false);
		initial();
		txtOrder.setText(no);
		txtID.setText(id);
		txtName.setText(name);
		txtPrice.setText(Double.toString(price));
		txtQuantity.setText(Integer.toString(quantity));
		txtTotal.setText(Double.toString(total));
	}
	public void btn() {
	    int quantity = Integer.parseInt(txtQuantity.getText());

	    if (quantity != 2) {
	    	btnSUB.setEnabled(true);

	    } else {
	        btnSUB.setEnabled(false);

	    }

	    if (quantity != 100) {
	        btnADD.setEnabled(true);

	    } else {
	        btnADD.setEnabled(false);

	    }
	}

	public void call() {
		conn = dbconnect();
		addToSales();
	}

	private Connection dbconnect() {
		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection("JDBC:sqlite:C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\sales.sqlite");
			return conn;
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"COnnection Error: " +e);
			return null;
		}
	}

	public void addToSales() {
		LocalDate currentDate = LocalDate.now();
		LocalTime currentTime = LocalTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
		String date = currentDate.toString();
		String time = currentTime.format(formatter);
		String id = txtID.getText();
		String item = txtName.getText();
		int quantity = Integer.parseInt(txtQuantity.getText());
		double price = Double.parseDouble(txtPrice.getText());
		double total = Double.parseDouble(txtTotal.getText());

		try {
			stmt = conn.createStatement();
			stmt.executeUpdate("insert into Sales (Date,Time,ID,Item,Quantity,Price,Total)"
					+ "values ('"+date+"','"+time+"','"+id+"','"+item+"',"+quantity+","+price+","+total+")");
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}

	public void main() {
		conn1 = connect();
		delete();
	}
	private Connection connect() {
		try {
			Class.forName("org.sqlite.JDBC");
			conn1 = DriverManager.getConnection("JDBC:sqlite:C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Cart.sqlite");
			return conn1;
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"COnnection Error: " +e);
			return null;
		}
	}

	public void getter(int i) {
		number = i;
	}
	public void delete() {
		String id = Integer.toString(number);
		try {
			stmt1 = conn1.createStatement();
			stmt1.executeUpdate("delete from Cart where Number = "+id+"");
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}
}
