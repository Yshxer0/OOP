package sales;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class Account {
	Connection conn = null;
	Statement stmt;
	PreparedStatement pst;
	ResultSet res;
	public String userName; 
	public String passWord;
	public String email;
	public String cName;
	public String mNo;
	public String job;
	
	public void loginUser(String uname) {
		conn = dbconnect();
		String username = uname;
		String query = "select * from Account where User = '"+username+"'";
	    try {
	        pst = conn.prepareStatement(query);
	        res = pst.executeQuery();
	        while (res.next()) {
	            userName = res.getString("User");
	            passWord = res.getString("Pass");
	            email = res.getString("Email");
	            cName = res.getString("Name");
	            mNo = res.getString("Number");
	            job = res.getString("Work");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	public void register(String user, String pass,String mail, String name, String no, String job ) {
		conn = dbconnect();
		String newuser = user;
		String newpass = pass;
		String newemail = mail;
		String newname = name;
		String newno = no;
		String newjob = job;
		try {
			
			stmt = conn.createStatement();
			stmt.executeUpdate("insert into Account (User,Pass,Email,Name,Number,Work)"
					+ "values ('"+newuser+"','"+newpass+"','"+newemail+"','"+newname+"','"+newno+"','"+newjob+"')");
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}
	
	private Connection dbconnect() {
	try {
		Class.forName("org.sqlite.JDBC");
		conn = DriverManager.getConnection("JDBC:sqlite:C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Account.sqlite");
		return conn;
	}
	catch(Exception e) {
		JOptionPane.showMessageDialog(null,"COnnection Error: " +e);
		return null;
	}
}
}

