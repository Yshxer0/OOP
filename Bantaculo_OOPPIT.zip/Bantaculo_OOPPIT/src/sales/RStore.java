package sales;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import ProductDB.*;


public class RStore {

	private JFrame frmLogin;
	private JPanel log;
	private JPanel items;
	private JPanel Inventory;
	private JPanel tablet;
	private JPanel smartPhone;
	private JPanel smartWatch;
	private JTextField txtOrder;
	private JTextField txtProductId;
	private JTextField txtTotal;
	private JTextField txtCash;
	private JTextField txtChange;
	private JLabel lblCash;
	private JLabel lblChange;
	private JButton btnPrint;
	private JButton btnSUB;
	private JButton btnADD;
	private JButton btnlaptop1;
	private JButton btnlaptop2;
	private JButton btnsmartPhone1;
	private JButton btnsmartPhone2;
	private JButton btnsmartWatch1;
	private JButton btnsmartWatch2;
	private JButton btntablet1;
	private JButton btntablet2;
	private JTextArea textArea;
	private JTextField txtStock;
	private JTextField txtPrice;
	private JTextArea txtItemName;
	private String y = "";
	private DefaultTableModel model;
	private DefaultTableModel model1;
	private String formattedDate;
	private String formattedTime;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					RStore window = new RStore();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public RStore() {
		initialize();
	}

	Laptop1 l1 = new Laptop1();
	Laptop2 l2 = new Laptop2();
	SmartP1 sp1 = new SmartP1();
	SmartP2 sp2 = new SmartP2();
	SmartW1 sw1 = new SmartW1();
	SmartW2 sw2 = new SmartW2();
	Tablet1 t1 = new Tablet1();
	Tablet2 t2 = new Tablet2();
	Account acc = new Account();
	DecimalFormat d = new DecimalFormat("0.00");
	private JTextField txtQuantity;
	private JTable table;

	Connection conn = null;
	Statement stmt;
	PreparedStatement pst;
	ResultSet res;

	private JTable table_1;
	private JTextField txtUName;
	private JTextField txtCName;
	private JTextField txtEmail;
	private JTextField txtMNo;
	private JTextField txtOcc;
	private JLabel label;
	private JLabel date;
	private JLabel time;
	private JLabel sales;

	Connection conn1 = null;
	Statement stmt1;
	PreparedStatement pst1;
	ResultSet res1;
	
	private JTextField txtDate;
	private JTextField txtTime;
	private JTextField txtpID;
	private JTextField txtiName;
	private JTextField txtNumber;
	private JTextField txtPID;
	private JTextField txtIName;
	private static int number;
	private JTextField txtUser;
	private JTextField txtRUser;
	private JTextField txtRPass;
	private JTextField txtREmail;
	private JTextField txtRC;
	private JTextField txtRM;
	private JTextField txtRO;
	private JPasswordField txtPass;

	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setTitle("Login");
		frmLogin.getContentPane().setBackground(new Color(255, 255, 255));
		frmLogin.getContentPane().setLayout(null);

		JPanel mainPanel = new JPanel();
		mainPanel.setBounds(0, 0, 1924, 1061);
		frmLogin.getContentPane().add(mainPanel);
		mainPanel.setLayout(new CardLayout(0, 0));

		JPanel Login = new JPanel();
		mainPanel.add(Login, "login");
		Login.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.WHITE, 3));
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(656, 340, 611, 371);
		Login.add(panel_2);
		panel_2.setLayout(null);
		
		log = new JPanel();
		log.setBounds(12, 61, 587, 298);
		panel_2.add(log);
		log.setLayout(new CardLayout(0, 0));
		
		JPanel Loginpanel = new JPanel();
		Loginpanel.setBackground(Color.WHITE);
		log.add(Loginpanel, "Login");
		Loginpanel.setLayout(null);
		
		JLabel lblNewLabel_13 = new JLabel("Username:");
		lblNewLabel_13.setFont(new Font("Dialog", Font.BOLD, 12));
		lblNewLabel_13.setBounds(315, 54, 161, 16);
		Loginpanel.add(lblNewLabel_13);
		
		txtUser = new JTextField();
		txtUser.setBounds(315, 71, 250, 26);
		Loginpanel.add(txtUser);
		txtUser.setColumns(10);
		
		JLabel lblNewLabel_13_1 = new JLabel("Password:");
		lblNewLabel_13_1.setFont(new Font("Dialog", Font.BOLD, 12));
		lblNewLabel_13_1.setBounds(315, 109, 161, 16);
		Loginpanel.add(lblNewLabel_13_1);
		
		JButton btnNewButton_4_2 = new JButton("Login");
		btnNewButton_4_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String uname = txtUser.getText();
				String pass = new String(txtPass.getPassword());
				acc.loginUser(uname);
				if(uname.equals(acc.userName) && pass.equals(acc.passWord)){
					JOptionPane.showMessageDialog(null, "Login Successfully","Logging in",JOptionPane.PLAIN_MESSAGE);
					CardLayout cardLayout = (CardLayout) mainPanel.getLayout();
					cardLayout.show(mainPanel, "customerPanel");
				}
				else {
					JOptionPane.showMessageDialog(null, "Error! Login Declined!","ERROR!",JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		btnNewButton_4_2.setBackground(Color.WHITE);
		btnNewButton_4_2.setBounds(398, 170, 98, 26);
		Loginpanel.add(btnNewButton_4_2);
		
		JLabel lblNewLabel_13_2 = new JLabel("LOGIN");
		lblNewLabel_13_2.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_13_2.setBounds(315, 16, 118, 26);
		Loginpanel.add(lblNewLabel_13_2);
		
		JPanel panel_5_1 = new JPanel();
		panel_5_1.setLayout(null);
		panel_5_1.setBackground(Color.BLACK);
		panel_5_1.setBounds(287, 16, 10, 270);
		Loginpanel.add(panel_5_1);
		
		JLabel lblNewLabel_15 = new JLabel("");
		lblNewLabel_15.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\s2.jpg"));
		lblNewLabel_15.setBounds(12, 16, 257, 270);
		Loginpanel.add(lblNewLabel_15);
		
		JLabel lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setBounds(381, 250, 133, 36);
		Loginpanel.add(lblNewLabel_14);
		lblNewLabel_14.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\samsung.png"));
		
		JRadioButton showPasswordRadioButton = new JRadioButton("Show");
		showPasswordRadioButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        JRadioButton radioButton = (JRadioButton) e.getSource();
		        if (radioButton.isSelected()) {
		            txtPass.setEchoChar((char) 0); // Show password
		        } else {
		            txtPass.setEchoChar('\u2022'); // Hide password with bullet character
		        }
		    }
		});
		showPasswordRadioButton.setBackground(Color.WHITE);
		showPasswordRadioButton.setBounds(504, 152, 61, 16);
		Loginpanel.add(showPasswordRadioButton);
		
		txtPass = new JPasswordField(20);
		txtPass.setBounds(315, 124, 252, 26);
		Loginpanel.add(txtPass);
		
		JPanel Register = new JPanel();
		Register.setBackground(Color.WHITE);
		log.add(Register, "Register");
		Register.setLayout(null);
		
		JLabel lblNewLabel_16 = new JLabel("Username:");
		lblNewLabel_16.setBounds(46, 47, 68, 16);
		Register.add(lblNewLabel_16);
		
		txtRUser = new JTextField();
		txtRUser.setBounds(46, 66, 225, 26);
		Register.add(txtRUser);
		txtRUser.setColumns(10);
		
		JLabel lblNewLabel_16_1 = new JLabel("Password:");
		lblNewLabel_16_1.setBounds(46, 104, 68, 16);
		Register.add(lblNewLabel_16_1);
		
		txtRPass = new JTextField();
		txtRPass.setColumns(10);
		txtRPass.setBounds(46, 121, 225, 26);
		Register.add(txtRPass);
		
		JLabel lblNewLabel_17 = new JLabel("Create New Account");
		lblNewLabel_17.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_17.setBounds(46, 12, 225, 23);
		Register.add(lblNewLabel_17);
		
		JLabel lblNewLabel_16_1_1 = new JLabel("Email:");
		lblNewLabel_16_1_1.setBounds(46, 159, 68, 16);
		Register.add(lblNewLabel_16_1_1);
		
		txtREmail = new JTextField();
		txtREmail.setColumns(10);
		txtREmail.setBounds(46, 175, 225, 26);
		Register.add(txtREmail);
		
		JLabel lblNewLabel_16_2 = new JLabel("Complete Name:");
		lblNewLabel_16_2.setBounds(316, 47, 93, 16);
		Register.add(lblNewLabel_16_2);
		
		txtRC = new JTextField();
		txtRC.setColumns(10);
		txtRC.setBounds(316, 66, 225, 26);
		Register.add(txtRC);
		
		txtRM = new JTextField();
		txtRM.setColumns(10);
		txtRM.setBounds(316, 124, 225, 26);
		Register.add(txtRM);
		
		txtRO = new JTextField();
		txtRO.setColumns(10);
		txtRO.setBounds(316, 178, 225, 26);
		Register.add(txtRO);
		
		JLabel lblNewLabel_16_2_1 = new JLabel("Mobile No.");
		lblNewLabel_16_2_1.setBounds(316, 104, 93, 16);
		Register.add(lblNewLabel_16_2_1);
		
		JLabel lblNewLabel_16_2_1_1 = new JLabel("Occupation");
		lblNewLabel_16_2_1_1.setBounds(316, 159, 93, 16);
		Register.add(lblNewLabel_16_2_1_1);
		
		JButton btnNewButton_4_1_1 = new JButton("Register");
		btnNewButton_4_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newuser = txtRUser.getText();
				String newpass = txtRPass.getText();
				String newemail = txtREmail.getText();
				String newname = txtRC.getText();
				String newno = txtRM.getText();
				String newjob = txtRO.getText();
				acc.register(newuser, newpass, newemail, newname, newno, newjob);
				JOptionPane.showMessageDialog(null, "Account Created Successfully");
			}
		});
		btnNewButton_4_1_1.setBackground(Color.WHITE);
		btnNewButton_4_1_1.setBounds(241, 231, 98, 37);
		Register.add(btnNewButton_4_1_1);
		
		JButton btnNewButton_4 = new JButton("Login");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) log.getLayout();
				cardLayout.show(log, "Login");
			}
		});
		btnNewButton_4.setBackground(Color.WHITE);
		btnNewButton_4.setBounds(190, 12, 98, 37);
		panel_2.add(btnNewButton_4);
		
		JButton btnNewButton_4_1 = new JButton("Register");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) log.getLayout();
				cardLayout.show(log, "Register");
			}
		});
		btnNewButton_4_1.setBackground(Color.WHITE);
		btnNewButton_4_1.setBounds(322, 12, 98, 37);
		panel_2.add(btnNewButton_4_1);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.WHITE);
		panel_5.setBounds(300, 12, 10, 37);
		panel_2.add(panel_5);
		panel_5.setLayout(null);
		frmLogin.setBounds(100, 100, 1940, 1100);
		frmLogin.setExtendedState(Frame.MAXIMIZED_BOTH);
		frmLogin.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\pass.jpg"));
		lblNewLabel_12.setBounds(0, 0, 1924, 1061);
		Login.add(lblNewLabel_12);
		
		JPanel customerPanel = new JPanel();
		mainPanel.add(customerPanel, "customerPanel");
		customerPanel.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1924, 75);
		customerPanel.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\samsung.png"));
		lblNewLabel.setBounds(12, 24, 120, 25);
		panel.add(lblNewLabel);

		JButton btnNewButton_1_1 = new JButton("");
		btnNewButton_1_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1_1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Picture2.png"));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) Inventory.getLayout();
				cardLayout.show(Inventory, "Cart");
				main2();
			}
		});
		btnNewButton_1_1.setBounds(1788, 12, 56, 51);
		panel.add(btnNewButton_1_1);

		JButton btnNewButton_1_2 = new JButton("");
		btnNewButton_1_2.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\myacc1.png"));
		btnNewButton_1_2.setBackground(new Color(255, 255, 255));
		btnNewButton_1_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) Inventory.getLayout();
				cardLayout.show(Inventory, "MyAcc");
				txtUName.setText(acc.userName);
				txtCName.setText(acc.cName);
				txtEmail.setText(acc.email);
				txtMNo.setText(acc.mNo);
				txtOcc.setText(acc.job);
				date();
				main4();
			}
		});
		btnNewButton_1_2.setBounds(1720, 12, 56, 51);
		panel.add(btnNewButton_1_2);

		JButton btnNewButton_1_3 = new JButton("Store Inventory");
		btnNewButton_1_3.setForeground(new Color(0, 0, 0));
		btnNewButton_1_3.setBackground(new Color(255, 255, 255));
		btnNewButton_1_3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) Inventory.getLayout();
				cardLayout.show(Inventory, "StoreI");
				txtOrder.setText("");
				txtItemName.setText("");
				txtProductId.setText("");
				textArea.setText("");
				txtPrice.setText("");
				txtStock.setText("");
				txtQuantity.setText("");
				txtTotal.setText("");
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnNewButton_1_3.setFont(new Font("Dialog", Font.BOLD, 20));
		btnNewButton_1_3.setBounds(139, 12, 256, 51);
		panel.add(btnNewButton_1_3);

		JButton btnNewButton_1_2_1 = new JButton("");
		btnNewButton_1_2_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1_2_1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\off5.jpg"));
		btnNewButton_1_2_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				java.lang.System.exit(0);
			}
		});
		btnNewButton_1_2_1.setBounds(1856, 12, 56, 51);
		panel.add(btnNewButton_1_2_1);

		Inventory = new JPanel();
		Inventory.setBounds(0, 74, 1924, 987);
		customerPanel.add(Inventory);
		Inventory.setLayout(new CardLayout(0, 0));

		JPanel Deco = new JPanel();
		Deco.setBackground(new Color(37, 37, 37));
		Inventory.add(Deco, "Deco");
		Deco.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(329, 163, 1288, 666);
		Deco.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_4 = new JLabel("WELCOME");
		lblNewLabel_4.setForeground(new Color(0, 0, 0));
		lblNewLabel_4.setFont(lblNewLabel_4.getFont().deriveFont(150f));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(12, 12, 1264, 164);
		panel_1.add(lblNewLabel_4);

		JLabel lblNewLabel_4_1 = new JLabel("TO");
		lblNewLabel_4_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setFont(new Font("Dialog", Font.BOLD, 80));
		lblNewLabel_4_1.setBounds(12, 127, 1264, 164);
		panel_1.add(lblNewLabel_4_1);

		JLabel lblNewLabel_4_1_2 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_2.setBackground(new Color(0, 0, 0));
		lblNewLabel_4_1_2.setToolTipText("");
		lblNewLabel_4_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_4_1_2.setFont(lblNewLabel_4_1_2.getFont().deriveFont(240f));
		lblNewLabel_4_1_2.setBounds(12, 255, 1264, 251);
		panel_1.add(lblNewLabel_4_1_2);

		JLabel lblNewLabel_4_1_2_1 = new JLabel("THE NEXT BIG THING");
		lblNewLabel_4_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_2_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_4_1_2_1.setFont(lblNewLabel_4_1_2_1.getFont().deriveFont(100f));
		lblNewLabel_4_1_2_1.setBounds(12, 518, 1264, 94);
		panel_1.add(lblNewLabel_4_1_2_1);

		JLabel lblNewLabel_4_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1.setBounds(-206, 12, 762, 139);
		Deco.add(lblNewLabel_4_1_1);
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1_1.setFont(lblNewLabel_4_1_1.getFont().deriveFont(150f));

		JPanel panel_4 = new JPanel();
		panel_4.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4.setBounds(556, 12, 802, 138);
		Deco.add(panel_4);
		panel_4.setLayout(null);

		JLabel lblNewLabel_4_1_1_5_1_2 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2.setFont(lblNewLabel_4_1_1_5_1_2.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2.setBounds(0, 0, 802, 138);
		panel_4.add(lblNewLabel_4_1_1_5_1_2);

		JLabel lblNewLabel_4_1_1_6 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_6.setBounds(1358, 12, 762, 138);
		Deco.add(lblNewLabel_4_1_1_6);
		lblNewLabel_4_1_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1_1_6.setFont(lblNewLabel_4_1_1_6.getFont().deriveFont(150f));

		JPanel panel_4_1 = new JPanel();
		panel_4_1.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4_1.setLayout(null);
		panel_4_1.setBounds(-226, 151, 782, 138);
		Deco.add(panel_4_1);

		JLabel lblNewLabel_4_1_1_5_1_2_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_1.setFont(lblNewLabel_4_1_1_5_1_2_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_1.setBounds(0, 0, 802, 138);
		panel_4_1.add(lblNewLabel_4_1_1_5_1_2_1);

		JLabel lblNewLabel_4_1_1_3 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_3.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_3.setFont(lblNewLabel_4_1_1_3.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_3.setBounds(578, 150, 762, 139);
		Deco.add(lblNewLabel_4_1_1_3);

		JPanel panel_4_1_1 = new JPanel();
		panel_4_1_1.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4_1_1.setLayout(null);
		panel_4_1_1.setBounds(1358, 151, 782, 138);
		Deco.add(panel_4_1_1);

		JLabel lblNewLabel_4_1_1_5_1_2_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_1_1.setBounds(-34, 0, 832, 138);
		panel_4_1_1.add(lblNewLabel_4_1_1_5_1_2_1_1);
		lblNewLabel_4_1_1_5_1_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_1_1.setFont(lblNewLabel_4_1_1_5_1_2_1_1.getFont().deriveFont(150f));

		JPanel panel_4_2 = new JPanel();
		panel_4_2.setLayout(null);
		panel_4_2.setBounds(556, 290, 802, 138);
		Deco.add(panel_4_2);

		JLabel lblNewLabel_4_1_1_5_1_2_2 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_2.setFont(lblNewLabel_4_1_1_5_1_2_2.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_2.setBounds(0, 0, 802, 138);
		panel_4_2.add(lblNewLabel_4_1_1_5_1_2_2);

		JLabel lblNewLabel_4_1_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_1.setBounds(-206, 290, 762, 139);
		Deco.add(lblNewLabel_4_1_1_1);
		lblNewLabel_4_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1.setFont(lblNewLabel_4_1_1_1.getFont().deriveFont(150f));

		JPanel panel_4_1_2 = new JPanel();
		panel_4_1_2.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4_1_2.setLayout(null);
		panel_4_1_2.setBounds(-226, 428, 782, 138);
		Deco.add(panel_4_1_2);

		JLabel lblNewLabel_4_1_1_5_1_2_1_2 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_1_2.setBackground(UIManager.getColor("CheckBox.background"));
		lblNewLabel_4_1_1_5_1_2_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_1_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_1_2.setFont(lblNewLabel_4_1_1_5_1_2_1_2.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_1_2.setBounds(0, 0, 802, 138);
		panel_4_1_2.add(lblNewLabel_4_1_1_5_1_2_1_2);

		JLabel lblNewLabel_4_1_1_1_2 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_1_2.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1_2.setFont(lblNewLabel_4_1_1_1_2.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_1_2.setBounds(-206, 565, 762, 139);
		Deco.add(lblNewLabel_4_1_1_1_2);

		JPanel panel_4_1_2_1 = new JPanel();
		panel_4_1_2_1.setLayout(null);
		panel_4_1_2_1.setBounds(-226, 704, 782, 138);
		Deco.add(panel_4_1_2_1);

		JLabel lblNewLabel_4_1_1_5_1_2_1_2_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_1_2_1.setBackground(UIManager.getColor("CheckBox.background"));
		lblNewLabel_4_1_1_5_1_2_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_1_2_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_1_2_1.setFont(lblNewLabel_4_1_1_5_1_2_1_2_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_1_2_1.setBounds(0, 0, 802, 138);
		panel_4_1_2_1.add(lblNewLabel_4_1_1_5_1_2_1_2_1);

		JLabel lblNewLabel_4_1_1_1_2_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_1_2_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1_2_1.setFont(lblNewLabel_4_1_1_1_2_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_1_2_1.setBounds(-206, 842, 762, 145);
		Deco.add(lblNewLabel_4_1_1_1_2_1);

		JLabel lblNewLabel_4_1_1_3_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_3_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_3_1.setFont(lblNewLabel_4_1_1_3_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_3_1.setBounds(578, 428, 762, 139);
		Deco.add(lblNewLabel_4_1_1_3_1);

		JPanel panel_4_2_1 = new JPanel();
		panel_4_2_1.setLayout(null);
		panel_4_2_1.setBounds(556, 566, 802, 138);
		Deco.add(panel_4_2_1);

		JLabel lblNewLabel_4_1_1_5_1_2_2_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_2_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_2_1.setFont(lblNewLabel_4_1_1_5_1_2_2_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_2_1.setBounds(0, 0, 802, 138);
		panel_4_2_1.add(lblNewLabel_4_1_1_5_1_2_2_1);

		JLabel lblNewLabel_4_1_1_3_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_3_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_3_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_3_1_1.setFont(lblNewLabel_4_1_1_3_1_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_3_1_1.setBounds(578, 704, 762, 139);
		Deco.add(lblNewLabel_4_1_1_3_1_1);

		JPanel panel_4_2_1_1 = new JPanel();
		panel_4_2_1_1.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4_2_1_1.setLayout(null);
		panel_4_2_1_1.setBounds(556, 842, 802, 133);
		Deco.add(panel_4_2_1_1);

		JLabel lblNewLabel_4_1_1_5_1_2_2_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_2_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_2_1_1.setFont(lblNewLabel_4_1_1_5_1_2_2_1_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_2_1_1.setBounds(0, 0, 802, 138);
		panel_4_2_1_1.add(lblNewLabel_4_1_1_5_1_2_2_1_1);

		JLabel lblNewLabel_4_1_1_6_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_6_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_6_1.setFont(lblNewLabel_4_1_1_6_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_6_1.setBounds(1358, 290, 762, 138);
		Deco.add(lblNewLabel_4_1_1_6_1);

		JPanel panel_4_1_1_1 = new JPanel();
		panel_4_1_1_1.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4_1_1_1.setLayout(null);
		panel_4_1_1_1.setBounds(1358, 428, 782, 138);
		Deco.add(panel_4_1_1_1);

		JLabel lblNewLabel_4_1_1_5_1_2_1_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_1_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_1_1_1.setFont(lblNewLabel_4_1_1_5_1_2_1_1_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_1_1_1.setBounds(-34, 0, 832, 138);
		panel_4_1_1_1.add(lblNewLabel_4_1_1_5_1_2_1_1_1);

		JLabel lblNewLabel_4_1_1_6_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_6_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_6_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_6_1_1.setFont(lblNewLabel_4_1_1_6_1_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_6_1_1.setBounds(1358, 566, 762, 138);
		Deco.add(lblNewLabel_4_1_1_6_1_1);

		JPanel panel_4_1_1_1_1 = new JPanel();
		panel_4_1_1_1_1.setBackground(UIManager.getColor("CheckBox.background"));
		panel_4_1_1_1_1.setLayout(null);
		panel_4_1_1_1_1.setBounds(1358, 704, 782, 138);
		Deco.add(panel_4_1_1_1_1);

		JLabel lblNewLabel_4_1_1_5_1_2_1_1_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_5_1_2_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_5_1_2_1_1_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_1_5_1_2_1_1_1_1.setFont(lblNewLabel_4_1_1_5_1_2_1_1_1_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_5_1_2_1_1_1_1.setBounds(-34, 0, 832, 138);
		panel_4_1_1_1_1.add(lblNewLabel_4_1_1_5_1_2_1_1_1_1);

		JLabel lblNewLabel_4_1_1_6_1_1_1 = new JLabel("SAMSUNG");
		lblNewLabel_4_1_1_6_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1_6_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_6_1_1_1.setFont(lblNewLabel_4_1_1_6_1_1_1.getFont().deriveFont(150f));
		lblNewLabel_4_1_1_6_1_1_1.setBounds(1358, 842, 762, 138);
		Deco.add(lblNewLabel_4_1_1_6_1_1_1);

		JPanel StoreInventory = new JPanel();
		StoreInventory.setBackground(new Color(0, 0, 0));
		Inventory.add(StoreInventory, "StoreI");
		StoreInventory.setLayout(null);

		JPanel btnPanel = new JPanel();
		btnPanel.setBackground(new Color(255, 255, 255));
		btnPanel.setBounds(12, 12, 1451, 70);
		StoreInventory.add(btnPanel);
		btnPanel.setLayout(null);

		JButton btnlaptop = new JButton("Laptop");
		btnlaptop.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) items.getLayout();
				cardLayout.show(items, "laptop");
				txtOrder.setText("");
				txtItemName.setText("");
				txtProductId.setText("");
				textArea.setText("");
				txtPrice.setText("");
				txtStock.setText("");
				txtQuantity.setText("");
				txtTotal.setText("");
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnlaptop.setForeground(new Color(0, 0, 0));
		btnlaptop.setFont(new Font("Dialog", Font.BOLD, 15));
		btnlaptop.setBackground(Color.WHITE);
		btnlaptop.setBounds(264, 12, 120, 45);
		btnPanel.add(btnlaptop);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\samsung.png"));
		lblNewLabel_1.setBounds(12, 12, 187, 45);
		btnPanel.add(lblNewLabel_1);

		JButton btnSmartPhone = new JButton("Smart Phone");
		btnSmartPhone.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) items.getLayout();
				cardLayout.show(items, "SmartPhone");
				txtOrder.setText("");
				txtItemName.setText("");
				txtProductId.setText("");
				textArea.setText("");
				txtPrice.setText("");
				txtStock.setText("");
				txtQuantity.setText("");
				txtTotal.setText("");
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnSmartPhone.setForeground(Color.BLACK);
		btnSmartPhone.setFont(new Font("Dialog", Font.BOLD, 15));
		btnSmartPhone.setBackground(Color.WHITE);
		btnSmartPhone.setBounds(396, 12, 130, 45);
		btnPanel.add(btnSmartPhone);

		JButton btnTablet = new JButton("Tablet");
		btnTablet.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) items.getLayout();
				cardLayout.show(items, "Tablet");
				txtOrder.setText("");
				txtItemName.setText("");
				txtProductId.setText("");
				textArea.setText("");
				txtPrice.setText("");
				txtStock.setText("");
				txtQuantity.setText("");
				txtTotal.setText("");
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnTablet.setForeground(Color.BLACK);
		btnTablet.setFont(new Font("Dialog", Font.BOLD, 15));
		btnTablet.setBackground(Color.WHITE);
		btnTablet.setBounds(680, 12, 120, 45);
		btnPanel.add(btnTablet);

		JButton btnSmartWatch = new JButton("Smart Watch");
		btnSmartWatch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cardLayout = (CardLayout) items.getLayout();
				cardLayout.show(items, "SmartWatch");
				txtOrder.setText("");
				txtItemName.setText("");
				txtProductId.setText("");
				textArea.setText("");
				txtPrice.setText("");
				txtStock.setText("");
				txtQuantity.setText("");
				txtTotal.setText("");
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnSmartWatch.setForeground(Color.BLACK);
		btnSmartWatch.setFont(new Font("Dialog", Font.BOLD, 15));
		btnSmartWatch.setBackground(Color.WHITE);
		btnSmartWatch.setBounds(538, 12, 130, 45);
		btnPanel.add(btnSmartWatch);

		JPanel payPanel = new JPanel();
		payPanel.setBackground(new Color(255, 255, 255));
		payPanel.setBounds(1475, 12, 437, 963);
		StoreInventory.add(payPanel);
		payPanel.setLayout(null);

		JLabel lblNewLabel_3 = new JLabel("Order No.");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3.setBounds(12, 12, 134, 40);
		payPanel.add(lblNewLabel_3);

		txtOrder = new JTextField();
		txtOrder.setHorizontalAlignment(SwingConstants.CENTER);
		txtOrder.setBackground(new Color(255, 255, 255));
		txtOrder.setEditable(false);
		txtOrder.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtOrder.setBounds(164, 12, 261, 40);
		payPanel.add(txtOrder);
		txtOrder.setColumns(10);

		JLabel lblNewLabel_3_1 = new JLabel("Product ID");
		lblNewLabel_3_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3_1.setBounds(12, 64, 134, 40);
		payPanel.add(lblNewLabel_3_1);

		txtProductId = new JTextField();
		txtProductId.setBackground(new Color(255, 255, 255));
		txtProductId.setHorizontalAlignment(SwingConstants.CENTER);
		txtProductId.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtProductId.setEditable(false);
		txtProductId.setColumns(10);
		txtProductId.setBounds(164, 64, 261, 40);
		payPanel.add(txtProductId);

		JLabel lblNewLabel_3_1_1 = new JLabel("Item ");
		lblNewLabel_3_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3_1_1.setBounds(12, 116, 134, 40);
		payPanel.add(lblNewLabel_3_1_1);

		JLabel lblNewLabel_3_1_1_1 = new JLabel("Description:");
		lblNewLabel_3_1_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3_1_1_1.setBounds(12, 168, 134, 40);
		payPanel.add(lblNewLabel_3_1_1_1);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 202, 413, 334);
		payPanel.add(scrollPane_1);

		textArea = new JTextArea();
		textArea.setFont(new Font("Dialog", Font.BOLD, 15));
		scrollPane_1.setViewportView(textArea);
		textArea.setEditable(false);

		JLabel lblNewLabel_3_1_1_2 = new JLabel("Price          Php");
		lblNewLabel_3_1_1_2.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3_1_1_2.setBounds(12, 548, 151, 40);
		payPanel.add(lblNewLabel_3_1_1_2);

		JLabel lblNewLabel_3_1_1_2_1 = new JLabel("Quantity");
		lblNewLabel_3_1_1_2_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3_1_1_2_1.setBounds(12, 649, 134, 40);
		payPanel.add(lblNewLabel_3_1_1_2_1);

		JLabel lblNewLabel_3_1_1_2_1_1 = new JLabel("Total          Php");
		lblNewLabel_3_1_1_2_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_3_1_1_2_1_1.setBounds(12, 701, 151, 40);
		payPanel.add(lblNewLabel_3_1_1_2_1_1);

		txtTotal = new JTextField();
		txtTotal.setBackground(new Color(255, 255, 255));
		txtTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotal.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtTotal.setEditable(false);
		txtTotal.setColumns(10);
		txtTotal.setBounds(164, 703, 261, 37);
		payPanel.add(txtTotal);

		JButton btnCheckOut = new JButton("Check Out");
		btnCheckOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				int i = Integer.parseInt(txtQuantity.getText());
				double c = Double.parseDouble(txtCash.getText());
				double t = Double.parseDouble(txtTotal.getText());
				
				if(y=="l1") {
					if(c>=t) {
						l1.purchase(i);
					l1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(l1.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="l2") {
					if(c>=t) {
						l2.purchase(i);
					l2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(l2.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="sp1") {
					if(c>=t) {
						sp1.purchase(i);
					sp1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sp1.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="sp2") {
					if(c>=t) {
						sp2.purchase(i);
					sp2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sp2.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="sw1") {
					if(c>=t) {
						sw1.purchase(i);
					sw1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sw1.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="sw2") {
					if(c>=t) {
						sw2.purchase(i);
					sw2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(sw2.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="t1") {
					if(c>=t) {
						t1.purchase(i);
					t1.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(t1.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
				else if(y=="t2") {
					if(c>=t) {
						t2.purchase(i);
					t2.computeChange(Double.parseDouble(txtCash.getText()), Double.parseDouble(txtTotal.getText()));
					txtChange.setText(d.format(t2.sales));
					int j = Integer.parseInt(txtStock.getText()) - i;
					txtStock.setText(Integer.toString(j));
					main3();
					}else {
						JOptionPane.showMessageDialog(null, "Insufficient Funds! Please Try Again!","ERROR!", JOptionPane.PLAIN_MESSAGE);
					}
				}
			}
		});
		btnCheckOut.setBounds(327, 801, 98, 26);
		payPanel.add(btnCheckOut);

		JButton btnAdd = new JButton("Add to Cart");
		btnAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				main1();
			}
		});
		btnAdd.setBounds(212, 801, 98, 26);
		payPanel.add(btnAdd);

		lblCash = new JLabel("Cash          Php");
		lblCash.setFont(new Font("Dialog", Font.BOLD, 20));
		lblCash.setBounds(12, 750, 151, 40);
		payPanel.add(lblCash);

		txtCash = new JTextField();
		txtCash.setHorizontalAlignment(SwingConstants.RIGHT);
		txtCash.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtCash.setColumns(10);
		txtCash.setBounds(164, 752, 261, 37);
		payPanel.add(txtCash);

		lblChange = new JLabel("Change      Php");
		lblChange.setFont(new Font("Dialog", Font.BOLD, 20));
		lblChange.setBounds(12, 837, 151, 40);
		payPanel.add(lblChange);

		txtChange = new JTextField();
		txtChange.setBackground(new Color(255, 255, 255));
		txtChange.setHorizontalAlignment(SwingConstants.RIGHT);
		txtChange.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtChange.setEditable(false);
		txtChange.setColumns(10);
		txtChange.setBounds(164, 839, 261, 37);

		payPanel.add(txtChange);
		btnPrint = new JButton("Print Reciept");
		btnPrint.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String uname = "XXXXXXXXXX";
				String email = "XXXXXXXXXX@gmail.com";
				String order = txtOrder.getText();
				String id = txtProductId.getText();
				String name = txtItemName.getText();
				int quantity = Integer.parseInt(txtQuantity.getText());
				double price = Double.parseDouble(txtPrice.getText());
				double total = Double.parseDouble(txtTotal.getText());
				double cash = Double.parseDouble(txtCash.getText());
				double change = Double.parseDouble(txtChange.getText());

				if(y=="l1") {
					l1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="l2") {
					l2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="sp1") {
					sp1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="sp2") {
					sp2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="sw1") {
					sw1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="sw2") {
					sw2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="t1") {
					t1.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				else if(y=="t2") {
					t2.generateReceipt(order, uname, email, id, name, quantity, price, total, cash, change);
				}
				
			}
		});
		btnPrint.setBounds(311, 888, 114, 26);
		payPanel.add(btnPrint);

		JLabel lblStock = new JLabel("Stocks");
		lblStock.setFont(new Font("Dialog", Font.BOLD, 20));
		lblStock.setBounds(12, 597, 134, 40);
		payPanel.add(lblStock);

		txtStock = new JTextField();
		txtStock.setBackground(new Color(255, 255, 255));
		txtStock.setHorizontalAlignment(SwingConstants.CENTER);
		txtStock.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtStock.setEditable(false);
		txtStock.setColumns(10);
		txtStock.setBounds(164, 599, 261, 37);
		payPanel.add(txtStock);

		txtPrice = new JTextField();
		txtPrice.setBackground(new Color(255, 255, 255));
		txtPrice.setHorizontalAlignment(SwingConstants.CENTER);
		txtPrice.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtPrice.setEditable(false);
		txtPrice.setColumns(10);
		txtPrice.setBounds(164, 551, 261, 37);
		payPanel.add(txtPrice);

		txtQuantity = new JTextField();
		txtQuantity.setFont(new Font("Dialog", Font.BOLD, 20));
		txtQuantity.setText("1");
		txtQuantity.setHorizontalAlignment(SwingConstants.CENTER);
		txtQuantity.setBounds(212, 649, 165, 40);
		payPanel.add(txtQuantity);
		txtQuantity.setColumns(10);

		btnSUB = new JButton("<");
		btnSUB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					  int i = Integer.parseInt(txtQuantity.getText());
					  int j = i - 1;
					  txtQuantity.setText(Integer.toString(j));
					  btn();
					  double k = Double.parseDouble(txtPrice.getText());
					  double l = Double.parseDouble(txtQuantity.getText());
					  double m = k*l;
					  txtTotal.setText(d.format(m));
			}
		});
		btnSUB.setBounds(164, 649, 41, 40);
		payPanel.add(btnSUB);

		btnADD = new JButton(">");
		btnADD.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					  int i = Integer.parseInt(txtQuantity.getText());
					  int j = i + 1;
					  txtQuantity.setText(Integer.toString(j));
					  btn();
					  double k = Double.parseDouble(txtPrice.getText());
					  double l = Double.parseDouble(txtQuantity.getText());
					  double m = k*l;
					  txtTotal.setText(d.format(m));
			}
		});
		btnADD.setBounds(384, 649, 41, 40);
		payPanel.add(btnADD);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(164, 116, 261, 58);
		payPanel.add(scrollPane);

		txtItemName = new JTextArea();
		txtItemName.setFont(new Font("Dialog", Font.BOLD, 20));
		scrollPane.setViewportView(txtItemName);
		txtItemName.setEditable(false);

		items = new JPanel();
		items.setBounds(12, 94, 1451, 881);
		StoreInventory.add(items);
		items.setLayout(new CardLayout(0, 0));

		JPanel laptop = new JPanel();
		laptop.setBackground(new Color(255, 255, 255));
		items.add(laptop, "laptop");
		laptop.setLayout(null);

		btnlaptop1 = new JButton("");
		btnlaptop1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					txtQuantity.setText("1");
					int i = Integer.parseInt(txtQuantity.getText());
					if(i==1) {
						btnSUB.setEnabled(false);
					}
					y = "l1";
					l1.main();
					l1.total = 1 * l1.price;
					txtTotal.setText(d.format(l1.total));
					txtProductId.setText(l1.id);
					txtItemName.setText(l1.name);
					textArea.setText(l1.description);
					txtPrice.setText(d.format(l1.price));
					txtStock.setText(Integer.toString(l1.quantity_stock));
					random();
					txtCash.setText("");
					txtChange.setText("");
			}
		});
		btnlaptop1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\2ndlaptop.jpg"));
		btnlaptop1.setBackground(new Color(255, 255, 255));
		btnlaptop1.setBounds(0, 12, 710, 782);
		laptop.add(btnlaptop1);

		btnlaptop2 = new JButton("");
		btnlaptop2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "l2";
				l2.main();
				l2.total = 1 * l2.price;
				txtTotal.setText(d.format(l2.total));
				txtProductId.setText(l2.id);
				txtItemName.setText(l2.name);
				textArea.setText(l2.description);
				txtPrice.setText(d.format(l2.price));
				txtStock.setText(Integer.toString(l2.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnlaptop2.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\3rdlptop.png"));
		btnlaptop2.setBackground(Color.WHITE);
		btnlaptop2.setBounds(729, 12, 710, 782);
		laptop.add(btnlaptop2);

		JLabel lblNewLabel_2 = new JLabel("Samsung Galaxy Book3 Pro 360");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(12, 806, 710, 41);
		laptop.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("Samsung Galaxy Book3 Pro");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setBounds(729, 806, 710, 41);
		laptop.add(lblNewLabel_2_1);

		smartPhone = new JPanel();
		smartPhone.setBackground(new Color(255, 255, 255));
		items.add(smartPhone, "SmartPhone");
		smartPhone.setLayout(null);

		btnsmartPhone1 = new JButton("");
		btnsmartPhone1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "sp1";
				sp1.main();
				sp1.total = 1 * sp1.price;
				txtTotal.setText(d.format(sp1.total));
				txtProductId.setText(sp1.id);
				txtItemName.setText(sp1.name);
				textArea.setText(sp1.description);
				txtPrice.setText(d.format(sp1.price));
				txtStock.setText(Integer.toString(sp1.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnsmartPhone1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\61bLefD79-L._AC_SL1020_.jpg"));
		btnsmartPhone1.setBackground(Color.WHITE);
		btnsmartPhone1.setBounds(12, 12, 710, 782);
		smartPhone.add(btnsmartPhone1);

		btnsmartPhone2 = new JButton("");
		btnsmartPhone2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "sp2";
				sp2.main();
				sp2.total = 1 * sp2.price;
				txtTotal.setText(d.format(sp2.total));
				txtProductId.setText(sp2.id);
				txtItemName.setText(sp2.name);
				textArea.setText(sp2.description);
				txtPrice.setText(d.format(sp2.price));
				txtStock.setText(Integer.toString(sp2.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnsmartPhone2.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\3rdsphone.jpg"));
		btnsmartPhone2.setBackground(Color.WHITE);
		btnsmartPhone2.setBounds(729, 12, 710, 782);
		smartPhone.add(btnsmartPhone2);

		JLabel lblNewLabel_2_2 = new JLabel("Samsung Galaxy S22 Ultra");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2.setBounds(12, 806, 710, 41);
		smartPhone.add(lblNewLabel_2_2);

		JLabel lblNewLabel_2_2_2 = new JLabel("Samsung Galaxy S21 Ultra");
		lblNewLabel_2_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2_2.setBounds(729, 806, 710, 41);
		smartPhone.add(lblNewLabel_2_2_2);

		smartWatch = new JPanel();
		smartWatch.setBackground(new Color(255, 255, 255));
		items.add(smartWatch, "SmartWatch");
		smartWatch.setLayout(null);

		btnsmartWatch1 = new JButton("");
		btnsmartWatch1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "sw1";
				sw1.main();
				sw1.total = 1 * sw1.price;
				txtTotal.setText(d.format(sw1.total));
				txtProductId.setText(sw1.id);
				txtItemName.setText(sw1.name);
				textArea.setText(sw1.description);
				txtPrice.setText(d.format(sw1.price));
				txtStock.setText(Integer.toString(sw1.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnsmartWatch1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Picture.png"));
		btnsmartWatch1.setBackground(new Color(27, 27, 27));
		btnsmartWatch1.setBounds(12, 12, 710, 782);
		smartWatch.add(btnsmartWatch1);

		btnsmartWatch2 = new JButton("");
		btnsmartWatch2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "sw2";
				sw2.main();
				sw2.total = 1 * sw2.price;
				txtTotal.setText(d.format(sw2.total));
				txtProductId.setText(sw2.id);
				txtItemName.setText(sw2.name);
				textArea.setText(sw2.description);
				txtPrice.setText(d.format(sw2.price));
				txtStock.setText(Integer.toString(sw2.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btnsmartWatch2.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Picture3.png"));
		btnsmartWatch2.setBackground(new Color(27, 27, 27));
		btnsmartWatch2.setBounds(729, 12, 710, 782);
		smartWatch.add(btnsmartWatch2);

		JLabel lblNewLabel_2_2_1 = new JLabel("Samsung Galaxy Watch 4");
		lblNewLabel_2_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2_1.setBounds(12, 806, 710, 41);
		smartWatch.add(lblNewLabel_2_2_1);

		JLabel lblNewLabel_2_2_1_2 = new JLabel("Samsung Galaxy Watch 5");
		lblNewLabel_2_2_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2_1_2.setBounds(729, 806, 710, 41);
		smartWatch.add(lblNewLabel_2_2_1_2);

		tablet = new JPanel();
		tablet.setBackground(new Color(255, 255, 255));
		items.add(tablet, "Tablet");
		tablet.setLayout(null);

		btntablet1 = new JButton("");
		btntablet1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "t1";
				t1.main();
				t1.total = 1 * t1.price;
				txtTotal.setText(d.format(t1.total));
				txtProductId.setText(t1.id);
				txtItemName.setText(t1.name);
				textArea.setText(t1.description);
				txtPrice.setText(d.format(t1.price));
				txtStock.setText(Integer.toString(t1.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btntablet1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\71Wy1cgxu3L._AC_SS450.jpg"));
		btntablet1.setBackground(Color.WHITE);
		btntablet1.setBounds(12, 12, 710, 782);
		tablet.add(btntablet1);

		JLabel lblNewLabel_2_2_1_1 = new JLabel("Samsung Galaxy Tab S8");
		lblNewLabel_2_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2_1_1.setBounds(12, 806, 710, 41);
		tablet.add(lblNewLabel_2_2_1_1);

		btntablet2 = new JButton("");
		btntablet2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtQuantity.setText("1");
				y = "t2";
				t2.main();
				t2.total = 1 * t2.price;
				txtTotal.setText(d.format(t2.total));
				txtProductId.setText(t2.id);
				txtItemName.setText(t2.name);
				textArea.setText(t2.description);
				txtPrice.setText(d.format(t2.price));
				txtStock.setText(Integer.toString(t2.quantity_stock));
				random();
				txtCash.setText("");
				txtChange.setText("");
			}
		});
		btntablet2.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Picture51.png"));
		btntablet2.setBackground(Color.WHITE);
		btntablet2.setBounds(729, 12, 710, 782);
		tablet.add(btntablet2);

		JLabel lblNewLabel_2_2_1_1_1 = new JLabel("Samsung Galaxy Tab S7 Plus (12.4\")");
		lblNewLabel_2_2_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2_1_1_1.setBounds(729, 806, 710, 41);
		tablet.add(lblNewLabel_2_2_1_1_1);

		JPanel Cart = new JPanel();
		Cart.setBackground(new Color(255, 255, 255));
		Inventory.add(Cart, "Cart");
		Cart.setLayout(null);

		JLabel lblNewLabel_22 = new JLabel("Shopping Cart");
		lblNewLabel_22.setBounds(24, 12, 356, 92);
		lblNewLabel_22.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_22.setFont(new Font("Dialog", Font.BOLD, 50));
		Cart.add(lblNewLabel_22);

		JPanel panel_4_3 = new JPanel();
		panel_4_3.setBackground(Color.LIGHT_GRAY);
		panel_4_3.setBounds(24, 116, 1888, 4);
		Cart.add(panel_4_3);

		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Picture2.png"));
		lblNewLabel_5.setBounds(376, 12, 86, 92);
		Cart.add(lblNewLabel_5);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(24, 141, 1498, 834);
		Cart.add(scrollPane_2);

		table = new JTable();
		scrollPane_2.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Item No.", "Product ID", "Item Name", "Quantity", "Price", "Total"
			}
		));
		model = (DefaultTableModel) table.getModel();

		JButton btnNewButton = new JButton("Check Out");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Random random = new Random();
				int randomNumber = random.nextInt(900000000) + 100000000;
				String no = Integer.toString(randomNumber);
				int i = Integer.parseInt(txtNumber.getText());
				int stock = 0;
				String query = "select * from Cart where Number = "+i+"";
				String name = null, id = null;
				double price = 0, total = 0;
				try {
			        pst = conn.prepareStatement(query);
			        res = pst.executeQuery();
			        while (res.next()) {
			            name = res.getString("Item");
			            id = res.getString("ID");
			            price = Double.parseDouble(res.getString("Price"));
			            stock = Integer.parseInt(res.getString("Quantity"));
			            total = Double.parseDouble(res.getString("Total"));
			        }
			    } catch (SQLException er) {
			        er.printStackTrace();
			    }
				Cart c = new Cart(no, id, name, price, stock, total);
				c.getter(i);
				c.setVisible(true);
			}
		});
		btnNewButton.setBounds(1793, 371, 107, 26);
		Cart.add(btnNewButton);

		label = new JLabel("");
		label.setFont(new Font("Dialog", Font.BOLD, 50));
		label.setBounds(1636, 12, 264, 92);
		Cart.add(label);

		JLabel lblNewLabel_9 = new JLabel("FILTERS");
		lblNewLabel_9.setFont(new Font("Dialog", Font.BOLD, 25));
		lblNewLabel_9.setBounds(1540, 157, 107, 26);
		Cart.add(lblNewLabel_9);

		JLabel lblNewLabel_11 = new JLabel("Item No.");
		lblNewLabel_11.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_11.setBounds(1540, 195, 107, 34);
		Cart.add(lblNewLabel_11);

		JLabel lblNewLabel_11_1 = new JLabel("Product ID");
		lblNewLabel_11_1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_11_1.setBounds(1540, 241, 107, 34);
		Cart.add(lblNewLabel_11_1);

		txtNumber = new JTextField();
		txtNumber.setFont(new Font("Dialog", Font.BOLD, 15));
		txtNumber.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumber.setBounds(1644, 195, 187, 34);
		Cart.add(txtNumber);
		txtNumber.setColumns(10);

		JButton btnNewButton_3 = new JButton(">>");
		btnNewButton_3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String number = txtNumber.getText();
				try {
					String query = "select * from Cart where Number = "+number+"";
					pst = conn.prepareStatement(query);
					res = pst.executeQuery();
					resutltSetToTableModel(res);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_3.setBounds(1847, 194, 53, 34);
		Cart.add(btnNewButton_3);

		txtPID = new JTextField();
		txtPID.setHorizontalAlignment(SwingConstants.CENTER);
		txtPID.setFont(new Font("Dialog", Font.BOLD, 15));
		txtPID.setColumns(10);
		txtPID.setBounds(1644, 241, 187, 34);
		Cart.add(txtPID);

		JButton btnNewButton_3_1 = new JButton(">>");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String pID = txtPID.getText();
				try {
					String query = "select * from Cart where ID = "+pID+"";
					pst = conn.prepareStatement(query);
					res = pst.executeQuery();
					resutltSetToTableModel(res);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_3_1.setBounds(1847, 241, 53, 34);
		Cart.add(btnNewButton_3_1);

		JLabel lblNewLabel_11_1_1 = new JLabel("Item Name");
		lblNewLabel_11_1_1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_11_1_1.setBounds(1540, 287, 107, 34);
		Cart.add(lblNewLabel_11_1_1);

		txtIName = new JTextField();
		txtIName.setFont(new Font("Dialog", Font.BOLD, 15));
		txtIName.setHorizontalAlignment(SwingConstants.CENTER);
		txtIName.setColumns(10);
		txtIName.setBounds(1644, 287, 187, 34);
		Cart.add(txtIName);

		JButton btnNewButton_3_1_1 = new JButton(">>");
		btnNewButton_3_1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String iName = txtIName.getText();
				try {
					String query = "select * from Cart where Item = "+iName+"";
					pst = conn.prepareStatement(query);
					res = pst.executeQuery();
					resutltSetToTableModel(res);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_3_1_1.setBounds(1847, 287, 53, 34);
		Cart.add(btnNewButton_3_1_1);

		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int i = Integer.parseInt(txtNumber.getText());
				try {
					stmt = conn.createStatement();
					stmt.executeUpdate("delete from Cart where Number = "+i+"");
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnDelete.setBounds(1674, 333, 107, 26);
		Cart.add(btnDelete);

		JButton btnClearFilters = new JButton("Clear Filters");
		btnClearFilters.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtNumber.setText("");
				txtPID.setText("");
				txtIName.setText("");
			}
		});
		btnClearFilters.setBounds(1793, 333, 107, 26);
		Cart.add(btnClearFilters);

		JButton btnLoadAllProducts = new JButton("See All");
		btnLoadAllProducts.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "select * from Cart";
					pst = conn.prepareStatement(query);
					res = pst.executeQuery();
					resutltSetToTableModel(res);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnLoadAllProducts.setBounds(1540, 333, 122, 26);
		Cart.add(btnLoadAllProducts);

		JPanel MyAcc = new JPanel();
		MyAcc.setBackground(new Color(255, 255, 255));
		Inventory.add(MyAcc, "MyAcc");
		MyAcc.setLayout(null);

		JPanel panel_4_3_1 = new JPanel();
		panel_4_3_1.setBackground(Color.LIGHT_GRAY);
		panel_4_3_1.setBounds(12, 112, 1900, 4);
		MyAcc.add(panel_4_3_1);

		JLabel lblNewLabel_22_1 = new JLabel("User Account");
		lblNewLabel_22_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_22_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_22_1.setFont(new Font("Dialog", Font.BOLD, 50));
		lblNewLabel_22_1.setBounds(12, 12, 356, 92);
		MyAcc.add(lblNewLabel_22_1);

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\myacc1.png"));
		lblNewLabel_6.setBounds(363, 12, 47, 92);
		MyAcc.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("Username:");
		lblNewLabel_7.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_7.setBounds(357, 152, 127, 26);
		MyAcc.add(lblNewLabel_7);

		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(12, 542, 1583, 433);
		MyAcc.add(scrollPane_3);

		table_1 = new JTable();
		table_1.setFont(new Font("Dialog", Font.PLAIN, 15));
		table_1.setBackground(new Color(255, 255, 255));
		scrollPane_3.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Date", "Time", "Product ID", "Item Name", "Quantity", "Price", "Total"
			}
		));
		model1 = (DefaultTableModel) table_1.getModel();

		JPanel panel_4_3_1_1 = new JPanel();
		panel_4_3_1_1.setBackground(Color.LIGHT_GRAY);
		panel_4_3_1_1.setBounds(12, 523, 1900, 4);
		MyAcc.add(panel_4_3_1_1);

		JLabel lblNewLabel_22_1_1 = new JLabel("Recent Bought");
		lblNewLabel_22_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_22_1_1.setForeground(Color.BLACK);
		lblNewLabel_22_1_1.setFont(new Font("Dialog", Font.BOLD, 50));
		lblNewLabel_22_1_1.setBounds(12, 419, 356, 92);
		MyAcc.add(lblNewLabel_22_1_1);

		JLabel lblNewLabel_6_1 = new JLabel("");
		lblNewLabel_6_1.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Picture2.png"));
		lblNewLabel_6_1.setBounds(363, 419, 69, 92);
		MyAcc.add(lblNewLabel_6_1);

		txtUName = new JTextField();
		txtUName.setEditable(false);
		txtUName.setHorizontalAlignment(SwingConstants.CENTER);
		txtUName.setFont(new Font("Dialog", Font.BOLD, 15));
		txtUName.setBounds(536, 154, 292, 29);
		MyAcc.add(txtUName);
		txtUName.setColumns(10);

		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setIcon(new ImageIcon("C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\acc2.png"));
		lblNewLabel_8.setBounds(22, 128, 305, 279);
		MyAcc.add(lblNewLabel_8);

		JLabel lblNewLabel_7_1 = new JLabel("Complete Name:");
		lblNewLabel_7_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_7_1.setBounds(357, 195, 198, 26);
		MyAcc.add(lblNewLabel_7_1);

		txtCName = new JTextField();
		txtCName.setEditable(false);
		txtCName.setHorizontalAlignment(SwingConstants.CENTER);
		txtCName.setFont(new Font("Dialog", Font.BOLD, 15));
		txtCName.setColumns(10);
		txtCName.setBounds(536, 193, 292, 29);
		MyAcc.add(txtCName);

		JLabel lblNewLabel_7_1_1 = new JLabel("Email:");
		lblNewLabel_7_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_7_1_1.setBounds(357, 233, 198, 26);
		MyAcc.add(lblNewLabel_7_1_1);

		JLabel lblNewLabel_7_1_1_1 = new JLabel("Mobile No.:");
		lblNewLabel_7_1_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_7_1_1_1.setBounds(357, 271, 198, 26);
		MyAcc.add(lblNewLabel_7_1_1_1);

		JLabel lblNewLabel_7_1_1_1_1 = new JLabel("Occupation:");
		lblNewLabel_7_1_1_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_7_1_1_1_1.setBounds(357, 309, 198, 26);
		MyAcc.add(lblNewLabel_7_1_1_1_1);

		txtEmail = new JTextField();
		txtEmail.setEditable(false);
		txtEmail.setFont(new Font("Dialog", Font.BOLD, 15));
		txtEmail.setHorizontalAlignment(SwingConstants.CENTER);
		txtEmail.setColumns(10);
		txtEmail.setBounds(536, 230, 292, 29);
		MyAcc.add(txtEmail);

		txtMNo = new JTextField();
		txtMNo.setEditable(false);
		txtMNo.setFont(new Font("Dialog", Font.BOLD, 15));
		txtMNo.setHorizontalAlignment(SwingConstants.CENTER);
		txtMNo.setColumns(10);
		txtMNo.setBounds(536, 268, 292, 29);
		MyAcc.add(txtMNo);

		txtOcc = new JTextField();
		txtOcc.setEditable(false);
		txtOcc.setFont(new Font("Dialog", Font.BOLD, 15));
		txtOcc.setHorizontalAlignment(SwingConstants.CENTER);
		txtOcc.setColumns(10);
		txtOcc.setBounds(536, 306, 292, 29);
		MyAcc.add(txtOcc);

		date = new JLabel("");
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setFont(new Font("Dialog", Font.BOLD, 20));
		date.setBounds(1720, 12, 173, 26);
		MyAcc.add(date);

		time = new JLabel("");
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Dialog", Font.BOLD, 20));
		time.setBounds(1720, 50, 173, 26);
		MyAcc.add(time);

		sales = new JLabel("");
		sales.setFont(new Font("Dialog", Font.BOLD, 30));
		sales.setHorizontalAlignment(SwingConstants.CENTER);
		sales.setBounds(1653, 444, 259, 67);
		MyAcc.add(sales);

		JButton btnNewButton_1 = new JButton("Delete All");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stmt1 = conn1.createStatement();
					stmt1.executeUpdate("delete from sales");
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(1814, 949, 98, 26);
		MyAcc.add(btnNewButton_1);

		txtDate = new JTextField();
		txtDate.setBounds(1700, 573, 146, 26);
		MyAcc.add(txtDate);
		txtDate.setColumns(10);

		JLabel lblNewLabel_10 = new JLabel("Date");
		lblNewLabel_10.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_10.setBounds(1613, 572, 86, 26);
		MyAcc.add(lblNewLabel_10);

		JLabel lblNewLabel_10_1 = new JLabel("Time");
		lblNewLabel_10_1.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_10_1.setBounds(1613, 610, 86, 26);
		MyAcc.add(lblNewLabel_10_1);

		JLabel lblNewLabel_10_2 = new JLabel("Product ID");
		lblNewLabel_10_2.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_10_2.setBounds(1613, 648, 86, 26);
		MyAcc.add(lblNewLabel_10_2);

		JLabel lblNewLabel_10_2_1 = new JLabel("Item Name");
		lblNewLabel_10_2_1.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_10_2_1.setBounds(1613, 686, 86, 26);
		MyAcc.add(lblNewLabel_10_2_1);

		txtTime = new JTextField();
		txtTime.setColumns(10);
		txtTime.setBounds(1700, 611, 146, 26);
		MyAcc.add(txtTime);

		txtpID = new JTextField();
		txtpID.setColumns(10);
		txtpID.setBounds(1700, 649, 146, 26);
		MyAcc.add(txtpID);

		txtiName = new JTextField();
		txtiName.setColumns(10);
		txtiName.setBounds(1700, 687, 146, 26);
		MyAcc.add(txtiName);

		JLabel lblNewLabel_10_3 = new JLabel("Filters");
		lblNewLabel_10_3.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_10_3.setBounds(1613, 542, 86, 26);
		MyAcc.add(lblNewLabel_10_3);

		JButton btnNewButton_2 = new JButton(">>");
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String date = txtDate.getText();
				try {
					String query = "select * from sales where Date = '"+date+"'";
					pst1 = conn1.prepareStatement(query);
					res1 = pst1.executeQuery();
					resutltSetToTableModel1(res1);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(1857, 573, 55, 26);
		MyAcc.add(btnNewButton_2);

		JButton btnNewButton_2_1 = new JButton(">>");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String time = txtTime.getText();
				try {
					String query = "select * from sales where Time = '"+time+"'";
					pst1 = conn1.prepareStatement(query);
					res1 = pst1.executeQuery();
					resutltSetToTableModel1(res1);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_2_1.setBounds(1857, 611, 55, 26);
		MyAcc.add(btnNewButton_2_1);

		JButton btnNewButton_2_2 = new JButton(">>");
		btnNewButton_2_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String productID = txtpID.getText();
				try {
					String query = "select * from sales where ID = '"+productID+"'";
					pst1 = conn1.prepareStatement(query);
					res1 = pst1.executeQuery();
					resutltSetToTableModel1(res1);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_2_2.setBounds(1857, 648, 55, 26);
		MyAcc.add(btnNewButton_2_2);

		JButton btnNewButton_2_3 = new JButton(">>");
		btnNewButton_2_3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String itemName = txtiName.getText();
				try {
					String query = "select * from sales where Item = '"+itemName+"'";
					pst1 = conn1.prepareStatement(query);
					res1 = pst1.executeQuery();
					resutltSetToTableModel1(res1);
				}
				catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		btnNewButton_2_3.setBounds(1857, 686, 55, 26);
		MyAcc.add(btnNewButton_2_3);

		JButton btnNewButton_1_4 = new JButton("Clear Filters");
		btnNewButton_1_4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtDate.setText("");
				txtTime.setText("");
				txtpID.setText("");
				txtiName.setText("");
			}
		});
		btnNewButton_1_4.setBounds(1801, 725, 111, 26);
		MyAcc.add(btnNewButton_1_4);

	}

	public void main1() {
		conn = dbconnect();
		addToCart();
	}
	public void main2() {
		conn = dbconnect();
		seeCart();
	}

	public void retrieve() {
		String query = "select Number from Cart order by Number desc limit 1";
		try {
			pst = conn.prepareStatement(query);
	        res = pst.executeQuery();
			while(res.next()) {
				number = res.getInt("Number");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	public void addToCart() {
		retrieve();
		String id = txtProductId.getText();
		String item = txtItemName.getText();
		int quantity = Integer.parseInt(txtQuantity.getText());
		double price = Double.parseDouble(txtPrice.getText());
		double total = Double.parseDouble(txtTotal.getText());

		try {
			number++;
			stmt = conn.createStatement();
			stmt.executeUpdate("insert into Cart (Number,ID,Item,Quantity,Price,Total)"
					+ "values ("+(number)+",'"+id+"','"+item+"',"+quantity+","+price+","+total+")");

		}
		catch(Exception er) {
			er.printStackTrace();
		}
		JOptionPane.showMessageDialog(null, "Added to cart Successfully");
	}


	private Connection dbconnect() {
		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection("JDBC:sqlite:C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\Cart.sqlite");
			return conn;
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"COnnection Error: " +e);
			return null;
		}
	}

	public void seeCart() {
		try {
			String query = "select * from Cart";
				pst = conn.prepareStatement(query);
				res = pst.executeQuery();
			resutltSetToTableModel(res);
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}

	private void resutltSetToTableModel(ResultSet res) {
		model.setRowCount(0);
		int count = 0;
		try {
			while (res.next()) {
				Object[] row = {res.getString("Number"), res.getString("ID"),res.getString("Item"),res.getString("Quantity"),res.getString("Price"),res.getString("Total")};
				model.addRow(row);
				count++;
			}
			label.setText(count+" Item/s");
			}catch(Exception err){
				JOptionPane.showMessageDialog(null, "Error: "+err);
			}
		}

	public void btn() {
	    int quantity = Integer.parseInt(txtQuantity.getText());

	    if (quantity == 1) {
	    	btnSUB.setEnabled(false);

	    }  else {
	        btnSUB.setEnabled(true);

	    }

	    if (quantity != 100) {
	        btnADD.setEnabled(true);

	    } else {
	        btnADD.setEnabled(false);

	    }
	}
	public void random() {
		Random random = new Random();
		int randomNumber = random.nextInt(900000000) + 100000000;
		txtOrder.setText(Integer.toString(randomNumber));
	}
	public void date() {
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
		formattedDate = currentDate.format(formatter);
		date.setText(formattedDate);

		int TIMER_DELAY_MS = 1000;
		Timer timer = new Timer(TIMER_DELAY_MS, e -> {
            LocalTime currentTime = LocalTime.now();
            DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("hh:mm:ss a");
            formattedTime = currentTime.format(formatter1);
            time.setText(formattedTime);
        });
        timer.start();
	}

	private Connection connect() {
		try {
			Class.forName("org.sqlite.JDBC");
			conn1 = DriverManager.getConnection("JDBC:sqlite:C:\\Users\\Nitro 5\\Desktop\\Final Assignment\\sales.sqlite");
			return conn1;
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"COnnection Error: " +e);
			return null;
		}
	}
	private void resutltSetToTableModel1(ResultSet res1) {
		model1.setRowCount(0);
		int count = 0;
		try {
			while (res1.next()) {
				Object[] row = {res1.getString("Date"),res1.getString("Time"),res1.getString("ID"),res1.getString("Item"),res1.getString("Quantity"),res1.getString("Price"),res1.getString("Total")};
				model1.addRow(row);
				count++;
			}
			sales.setText(count+" Items Bought");
			}catch(Exception err){
				JOptionPane.showMessageDialog(null, "Error: "+err);
			}
		}
	public void seeSales() {
		try {
			String query = "select * from Sales";
				pst1 = conn1.prepareStatement(query);
				res1 = pst1.executeQuery();
			resutltSetToTableModel1(res1);
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}

	public void addToSales() {
		LocalDate currentDate = LocalDate.now();
		LocalTime currentTime = LocalTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
		String date = currentDate.toString();
		String time = currentTime.format(formatter);
		String id = txtProductId.getText();
		String item = txtItemName.getText();
		int quantity = Integer.parseInt(txtQuantity.getText());
		double price = Double.parseDouble(txtPrice.getText());
		double total = Double.parseDouble(txtTotal.getText());

		try {
			stmt1 = conn1.createStatement();
			stmt1.executeUpdate("insert into Sales (Date,Time,ID,Item,Quantity,Price,Total)"
					+ "values ('"+date+"','"+time+"','"+id+"','"+item+"',"+quantity+","+price+","+total+")");
		}
		catch(Exception er) {
			er.printStackTrace();
		}
	}

	public void main3() {
		conn1 = connect();
		addToSales();
	}
	public void main4() {
		conn1 = connect();
		seeSales();
	}
}
